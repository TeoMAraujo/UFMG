#ifndef CAMPEONATO_HPP
#define CAMPEONATO_HPP

#include <vector>
#include "Treinador.hpp"

class Campeonato {
private:
    std::vector<Treinador*> _treinadores; // vector<Treinador*> _treinadores;

public:
    Campeonato();
    ~Campeonato();

    void cadastrar_treinador(std::string nome); // método para cadastro de treinadores

    void cadastrar_pokemon_eletrico(int idt, std::string nome, std::string tipo_ataque, double forca_ataque, double potencia_raio); // Métodos para cadastro de pokemons específicos
    void cadastrar_pokemon_aquatico(int idt, std::string nome, std::string tipo_ataque, double forca_ataque, double litros_jato); // Métodos para cadastro de pokemons específicos
    void cadastrar_pokemon_explosivo(int idt, std::string nome, std::string tipo_ataque, double forca_ataque, double temperatura_explosao); // Métodos para cadastro de pokemons específicos

    void imprimir_informacoes_treinador(int idt); // método que imprime as informações de um determinado treinador
    void executar_batalha(int idt1, int idpk1, int idt2, int idpk2); // executa uma batalha considerandos os Treinadores/Pokemons informados
};

#endif

